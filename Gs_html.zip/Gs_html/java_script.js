document.getElementById('contactForm').addEventListener('submit', function(event) {
    event.preventDefault();
    
    const nome = document.getElementById('nome').value;
    const email = document.getElementById('email_js').value;
    const telefone = document.getElementById('telefone_js').value;
    const mensagem = document.getElementById('mensagem').value;
    
    alert(`Nome: ${nome}\nEmail: ${email}\nTelefone: ${telefone}\nMensagem: ${mensagem}`);
    
})